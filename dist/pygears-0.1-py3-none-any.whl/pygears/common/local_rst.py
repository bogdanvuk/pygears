from pygears import gear
from pygears.typing import Unit


@gear
def local_rst(din: Unit):
    pass
