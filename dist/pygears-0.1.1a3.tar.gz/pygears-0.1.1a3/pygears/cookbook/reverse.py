from pygears import gear


@gear
def reverse(din: 'TDin') -> b'TDin':
    pass
