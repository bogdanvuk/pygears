from pygears import gear


@gear
def align(*din, lvl) -> b'din':
    pass
