from pygears import gear


@gear(enablement=False)
def fmap(din, *, f):
    pass
